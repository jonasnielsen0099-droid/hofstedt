import { ServiceConfig } from '../types';

export const serviceQuestions: Record<string, Question[]> = {
  'Window Cleaning': [
    {
      id: 'frequency',
      type: 'select',
      label: 'How often do you need window cleaning?',
      required: true,
      options: ['One-time', 'Weekly', 'Bi-weekly', 'Monthly', 'Quarterly', 'Twice a year']
    },
    {
      id: 'numberOfWindows',
      type: 'number',
      label: 'How many windows need cleaning?',
      placeholder: 'Enter number of windows',
      required: true
    },
    {
      id: 'propertyType',
      type: 'select',
      label: 'Property type',
      required: true,
      options: ['Residential - Single story', 'Residential - Multi story', 'Commercial - Small', 'Commercial - Large']
    },
    {
      id: 'interiorExterior',
      type: 'radio',
      label: 'Interior, exterior, or both?',
      required: true,
      options: ['Interior only', 'Exterior only', 'Both interior and exterior']
    },
    {
      id: 'accessEquipment',
      type: 'radio',
      label: 'Is special equipment needed for access?',
      required: true,
      options: ['No, ground level access', 'Yes, ladder needed', 'Yes, lift/scaffolding needed']
    }
  ],
  'Garden Maintenance': [
    {
      id: 'frequency',
      type: 'select',
      label: 'How often do you need garden maintenance?',
      required: true,
      options: ['One-time', 'Weekly', 'Bi-weekly', 'Monthly', 'Seasonal']
    },
    {
      id: 'gardenSize',
      type: 'select',
      label: 'Garden size',
      required: true,
      options: ['Small (up to 100 m²)', 'Medium (100-300 m²)', 'Large (300-500 m²)', 'Very large (500+ m²)']
    },
    {
      id: 'servicesNeeded',
      type: 'textarea',
      label: 'What services do you need? (e.g., lawn mowing, hedge trimming, weeding, planting)',
      placeholder: 'Please describe the services you need',
      required: true
    },
    {
      id: 'currentCondition',
      type: 'select',
      label: 'Current garden condition',
      required: true,
      options: ['Well maintained', 'Needs regular care', 'Overgrown/needs renovation']
    }
  ],
  'Property Cleaning': [
    {
      id: 'frequency',
      type: 'select',
      label: 'How often do you need cleaning?',
      required: true,
      options: ['One-time deep clean', 'Weekly', 'Bi-weekly', 'Monthly']
    },
    {
      id: 'propertyType',
      type: 'select',
      label: 'Property type',
      required: true,
      options: ['Apartment', 'House', 'Office - Small', 'Office - Large', 'Commercial space']
    },
    {
      id: 'propertySize',
      type: 'number',
      label: 'Property size (square meters)',
      placeholder: 'Enter size in m²',
      required: true
    },
    {
      id: 'numberOfRooms',
      type: 'number',
      label: 'Number of rooms',
      placeholder: 'Enter number of rooms',
      required: true
    },
    {
      id: 'specialRequirements',
      type: 'textarea',
      label: 'Any special requirements or areas that need extra attention?',
      placeholder: 'e.g., pet hair, carpets, windows included, etc.',
      required: false
    }
  ],
  'Snow Removal': [
    {
      id: 'serviceType',
      type: 'select',
      label: 'Type of service needed',
      required: true,
      options: ['One-time clearing', 'Seasonal contract', 'On-call service']
    },
    {
      id: 'areaSize',
      type: 'select',
      label: 'Area size',
      required: true,
      options: ['Small driveway', 'Large driveway', 'Parking lot - Small', 'Parking lot - Large', 'Walkways only', 'Multiple areas']
    },
    {
      id: 'saltingNeeded',
      type: 'radio',
      label: 'Do you need salting/gritting service?',
      required: true,
      options: ['Yes', 'No']
    },
    {
      id: 'priority',
      type: 'select',
      label: 'Service priority',
      required: true,
      options: ['Standard (cleared by 8 AM)', 'Priority (cleared by 6 AM)', 'Emergency (cleared ASAP)']
    }
  ],
  'Gutter Cleaning': [
    {
      id: 'frequency',
      type: 'select',
      label: 'How often do you need gutter cleaning?',
      required: true,
      options: ['One-time', 'Twice a year (Spring/Fall)', 'Quarterly', 'As needed']
    },
    {
      id: 'gutterLength',
      type: 'number',
      label: 'Approximate total gutter length (meters)',
      placeholder: 'Enter length in meters',
      required: true
    },
    {
      id: 'stories',
      type: 'select',
      label: 'Building height',
      required: true,
      options: ['Single story', 'Two stories', 'Three+ stories']
    },
    {
      id: 'condition',
      type: 'select',
      label: 'Current gutter condition',
      required: true,
      options: ['Good - just needs cleaning', 'Some debris buildup', 'Heavy blockage', 'Not sure']
    },
    {
      id: 'guards',
      type: 'radio',
      label: 'Are you interested in gutter guards installation?',
      required: true,
      options: ['Yes, please include in quote', 'No, just cleaning', 'Tell me more']
    }
  ],
  'Pressure Washing': [
    {
      id: 'surfaceType',
      type: 'textarea',
      label: 'What surfaces need pressure washing? (e.g., driveway, patio, deck, siding)',
      placeholder: 'Describe the surfaces',
      required: true
    },
    {
      id: 'totalArea',
      type: 'number',
      label: 'Approximate total area (square meters)',
      placeholder: 'Enter size in m²',
      required: true
    },
    {
      id: 'surfaceCondition',
      type: 'select',
      label: 'Surface condition',
      required: true,
      options: ['Lightly soiled', 'Moderately dirty', 'Heavily stained/mossy', 'Very dirty/damaged']
    },
    {
      id: 'frequency',
      type: 'select',
      label: 'How often do you need this service?',
      required: true,
      options: ['One-time', 'Annually', 'Bi-annually', 'As needed']
    }
  ]
};

interface Question {
  id: string;
  type: 'text' | 'number' | 'select' | 'radio' | 'textarea';
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
}
