export interface Service {
  id: string;
  name: string;
  description: string;
  icon: string;
  active: boolean;
  created_at: string;
}

export interface QuoteRequest {
  id?: string;
  service_id: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  customer_address: string;
  answers: Record<string, string | number | boolean>;
  additional_notes: string;
  status?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Question {
  id: string;
  type: 'text' | 'number' | 'select' | 'radio' | 'textarea';
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
}

export interface ServiceConfig {
  serviceId: string;
  questions: Question[];
}
