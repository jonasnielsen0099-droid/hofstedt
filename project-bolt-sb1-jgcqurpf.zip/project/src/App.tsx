import QuoteForm from './components/QuoteForm';
import { Sparkles } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="container mx-auto px-4 py-12">
        <header className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-2xl mb-4 shadow-lg">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Hofstedt Ejendomsservice
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get a free, personalized quote for your property service needs in minutes
          </p>
        </header>

        <main>
          <QuoteForm />
        </main>

        <footer className="text-center mt-16 pt-8 border-t border-gray-200">
          <p className="text-gray-600">
            Questions? Contact us at{' '}
            <a href="mailto:info@hofstedt-ejendomsservice.dk" className="text-blue-600 hover:text-blue-700 font-medium">
              info@hofstedt-ejendomsservice.dk
            </a>
          </p>
        </footer>
      </div>
    </div>
  );
}

export default App;
