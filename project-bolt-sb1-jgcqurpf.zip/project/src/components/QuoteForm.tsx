import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Service, QuoteRequest } from '../types';
import { serviceQuestions } from '../config/serviceQuestions';
import { Check, ArrowRight, ArrowLeft, Loader } from 'lucide-react';

type Step = 'service' | 'questions' | 'contact' | 'success';

export default function QuoteForm() {
  const [currentStep, setCurrentStep] = useState<Step>('service');
  const [services, setServices] = useState<Service[]>([]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [answers, setAnswers] = useState<Record<string, string | number>>({});
  const [contactInfo, setContactInfo] = useState({
    customer_name: '',
    customer_email: '',
    customer_phone: '',
    customer_address: '',
    additional_notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    const { data, error } = await supabase
      .from('services')
      .select('*')
      .eq('active', true)
      .order('name');

    if (error) {
      console.error('Error loading services:', error);
      return;
    }

    setServices(data || []);
  };

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service);
    setAnswers({});
    setCurrentStep('questions');
  };

  const handleAnswerChange = (questionId: string, value: string | number) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const handleContactChange = (field: string, value: string) => {
    setContactInfo(prev => ({ ...prev, [field]: value }));
  };

  const validateQuestions = () => {
    if (!selectedService) return false;
    const questions = serviceQuestions[selectedService.name] || [];
    return questions
      .filter(q => q.required)
      .every(q => answers[q.id] && answers[q.id].toString().trim() !== '');
  };

  const validateContact = () => {
    return contactInfo.customer_name.trim() !== '' &&
           contactInfo.customer_email.trim() !== '' &&
           contactInfo.customer_phone.trim() !== '';
  };

  const handleSubmit = async () => {
    if (!selectedService || !validateContact()) return;

    setLoading(true);
    setError('');

    const quoteRequest: Omit<QuoteRequest, 'id' | 'created_at' | 'updated_at'> = {
      service_id: selectedService.id,
      customer_name: contactInfo.customer_name,
      customer_email: contactInfo.customer_email,
      customer_phone: contactInfo.customer_phone,
      customer_address: contactInfo.customer_address,
      answers: answers,
      additional_notes: contactInfo.additional_notes,
      status: 'new'
    };

    const { error } = await supabase
      .from('quote_requests')
      .insert(quoteRequest);

    setLoading(false);

    if (error) {
      setError('Failed to submit quote request. Please try again.');
      console.error('Error submitting quote:', error);
      return;
    }

    setCurrentStep('success');
  };

  const resetForm = () => {
    setCurrentStep('service');
    setSelectedService(null);
    setAnswers({});
    setContactInfo({
      customer_name: '',
      customer_email: '',
      customer_phone: '',
      customer_address: '',
      additional_notes: ''
    });
    setError('');
  };

  const renderServiceSelection = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Select a Service</h2>
        <p className="text-gray-600">Choose the service you need to get a customized quote</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
        {services.map(service => (
          <button
            key={service.id}
            onClick={() => handleServiceSelect(service)}
            className="p-6 bg-white border-2 border-gray-200 rounded-xl hover:border-blue-500 hover:shadow-lg transition-all duration-200 text-left group"
          >
            <div className="flex flex-col h-full">
              <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                {service.name}
              </h3>
              <p className="text-gray-600 text-sm flex-grow">{service.description}</p>
              <div className="mt-4 flex items-center text-blue-600 font-medium">
                Get Quote
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );

  const renderQuestions = () => {
    if (!selectedService) return null;
    const questions = serviceQuestions[selectedService.name] || [];

    return (
      <div className="space-y-6">
        <div>
          <button
            onClick={() => setCurrentStep('service')}
            className="flex items-center text-blue-600 hover:text-blue-700 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to services
          </button>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">{selectedService.name}</h2>
          <p className="text-gray-600">Please answer a few questions to help us provide an accurate quote</p>
        </div>

        <div className="space-y-6 bg-white p-8 rounded-xl border border-gray-200">
          {questions.map((question, index) => (
            <div key={question.id} className="space-y-2">
              <label className="block text-sm font-medium text-gray-900">
                {index + 1}. {question.label}
                {question.required && <span className="text-red-500 ml-1">*</span>}
              </label>

              {question.type === 'text' && (
                <input
                  type="text"
                  value={answers[question.id] || ''}
                  onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                  placeholder={question.placeholder}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required={question.required}
                />
              )}

              {question.type === 'number' && (
                <input
                  type="number"
                  value={answers[question.id] || ''}
                  onChange={(e) => handleAnswerChange(question.id, parseInt(e.target.value) || 0)}
                  placeholder={question.placeholder}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required={question.required}
                  min="0"
                />
              )}

              {question.type === 'select' && (
                <select
                  value={answers[question.id] || ''}
                  onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required={question.required}
                >
                  <option value="">Select an option</option>
                  {question.options?.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              )}

              {question.type === 'radio' && (
                <div className="space-y-2">
                  {question.options?.map(option => (
                    <label key={option} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="radio"
                        name={question.id}
                        value={option}
                        checked={answers[question.id] === option}
                        onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                        className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                        required={question.required}
                      />
                      <span className="text-gray-900">{option}</span>
                    </label>
                  ))}
                </div>
              )}

              {question.type === 'textarea' && (
                <textarea
                  value={answers[question.id] || ''}
                  onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                  placeholder={question.placeholder}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required={question.required}
                />
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-end">
          <button
            onClick={() => setCurrentStep('contact')}
            disabled={!validateQuestions()}
            className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center font-medium transition-colors"
          >
            Continue to Contact Info
            <ArrowRight className="ml-2 w-5 h-5" />
          </button>
        </div>
      </div>
    );
  };

  const renderContact = () => (
    <div className="space-y-6">
      <div>
        <button
          onClick={() => setCurrentStep('questions')}
          className="flex items-center text-blue-600 hover:text-blue-700 mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to questions
        </button>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Your Contact Information</h2>
        <p className="text-gray-600">We'll use this information to send you a personalized quote</p>
      </div>

      <div className="bg-white p-8 rounded-xl border border-gray-200 space-y-6">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-900">
            Full Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={contactInfo.customer_name}
            onChange={(e) => handleContactChange('customer_name', e.target.value)}
            placeholder="Enter your full name"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-900">
            Email Address <span className="text-red-500">*</span>
          </label>
          <input
            type="email"
            value={contactInfo.customer_email}
            onChange={(e) => handleContactChange('customer_email', e.target.value)}
            placeholder="your.email@example.com"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-900">
            Phone Number <span className="text-red-500">*</span>
          </label>
          <input
            type="tel"
            value={contactInfo.customer_phone}
            onChange={(e) => handleContactChange('customer_phone', e.target.value)}
            placeholder="+45 12 34 56 78"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-900">
            Property Address
          </label>
          <input
            type="text"
            value={contactInfo.customer_address}
            onChange={(e) => handleContactChange('customer_address', e.target.value)}
            placeholder="Enter property address"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-900">
            Additional Notes
          </label>
          <textarea
            value={contactInfo.additional_notes}
            onChange={(e) => handleContactChange('additional_notes', e.target.value)}
            placeholder="Any additional information that might help us provide a better quote"
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="flex justify-end">
        <button
          onClick={handleSubmit}
          disabled={!validateContact() || loading}
          className="px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center font-medium transition-colors"
        >
          {loading ? (
            <>
              <Loader className="animate-spin mr-2 w-5 h-5" />
              Submitting...
            </>
          ) : (
            <>
              Submit Quote Request
              <Check className="ml-2 w-5 h-5" />
            </>
          )}
        </button>
      </div>
    </div>
  );

  const renderSuccess = () => (
    <div className="text-center py-12">
      <div className="mb-6 inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full">
        <Check className="w-8 h-8 text-green-600" />
      </div>

      <h2 className="text-3xl font-bold text-gray-900 mb-4">Quote Request Submitted!</h2>

      <p className="text-lg text-gray-600 mb-2">
        Thank you for your interest in our {selectedService?.name} service.
      </p>

      <p className="text-gray-600 mb-8">
        We've received your request and will get back to you within 24 hours with a personalized quote.
      </p>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8 max-w-md mx-auto">
        <p className="text-sm text-gray-700">
          <strong>What happens next?</strong>
          <br />
          Our team will review your requirements and prepare a detailed quote tailored to your needs.
          You'll receive an email at <strong>{contactInfo.customer_email}</strong> with the quote and next steps.
        </p>
      </div>

      <button
        onClick={resetForm}
        className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors"
      >
        Request Another Quote
      </button>
    </div>
  );

  return (
    <div className="w-full max-w-5xl mx-auto">
      {currentStep === 'service' && renderServiceSelection()}
      {currentStep === 'questions' && renderQuestions()}
      {currentStep === 'contact' && renderContact()}
      {currentStep === 'success' && renderSuccess()}
    </div>
  );
}
