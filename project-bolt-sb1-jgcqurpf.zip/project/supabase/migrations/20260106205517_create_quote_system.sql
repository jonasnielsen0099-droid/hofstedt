/*
  # Quote Request System

  1. New Tables
    - `services`
      - `id` (uuid, primary key) - Unique identifier for each service
      - `name` (text) - Service name (e.g., "Window Cleaning")
      - `description` (text) - Brief description of the service
      - `icon` (text) - Icon identifier for UI
      - `active` (boolean) - Whether service is currently offered
      - `created_at` (timestamptz) - Record creation timestamp
    
    - `quote_requests`
      - `id` (uuid, primary key) - Unique identifier for each quote request
      - `service_id` (uuid, foreign key) - Reference to selected service
      - `customer_name` (text) - Customer's full name
      - `customer_email` (text) - Customer's email address
      - `customer_phone` (text) - Customer's phone number
      - `customer_address` (text) - Property address for service
      - `answers` (jsonb) - Dynamic answers to service-specific questions
      - `additional_notes` (text) - Any additional customer notes
      - `status` (text) - Quote status (new, reviewing, quoted, accepted, rejected)
      - `created_at` (timestamptz) - Request submission timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on all tables
    - Public can read active services
    - Public can insert quote requests (contact form use case)
    - Only authenticated users can view/manage quote requests
*/

-- Create services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  icon text DEFAULT 'package',
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create quote_requests table
CREATE TABLE IF NOT EXISTS quote_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid REFERENCES services(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text DEFAULT '',
  customer_address text DEFAULT '',
  answers jsonb DEFAULT '{}'::jsonb,
  additional_notes text DEFAULT '',
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_requests ENABLE ROW LEVEL SECURITY;

-- Services policies: Public can read active services
CREATE POLICY "Anyone can view active services"
  ON services FOR SELECT
  USING (active = true);

CREATE POLICY "Authenticated users can manage services"
  ON services FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Quote requests policies: Public can insert, authenticated can manage
CREATE POLICY "Anyone can submit quote requests"
  ON quote_requests FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view all quote requests"
  ON quote_requests FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update quote requests"
  ON quote_requests FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert initial services
INSERT INTO services (name, description, icon) VALUES
  ('Window Cleaning', 'Professional window cleaning for residential and commercial properties', 'square-stack'),
  ('Garden Maintenance', 'Complete garden care including lawn mowing, hedge trimming, and seasonal cleanup', 'flower'),
  ('Property Cleaning', 'Thorough cleaning services for homes and offices', 'home'),
  ('Snow Removal', 'Winter snow clearing and salting services', 'snowflake'),
  ('Gutter Cleaning', 'Professional gutter cleaning and maintenance', 'droplets'),
  ('Pressure Washing', 'High-pressure cleaning for driveways, patios, and building exteriors', 'droplet')
ON CONFLICT DO NOTHING;
